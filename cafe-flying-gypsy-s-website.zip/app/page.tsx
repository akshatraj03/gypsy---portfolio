'use client'

import { useState } from 'react'
import {
  ArrowUpRight,
  CalendarDays,
  Coffee,
  Compass,
  Menu,
  Minus,
  Phone,
  Plus,
  Sparkles,
  X,
} from 'lucide-react'

const menuGroups = [
  { title: 'Coffee & chai', items: ['Espresso', 'Cappuccino', 'Cold coffee', 'Masala chai'] },
  { title: 'Comfort plates', items: ['Maggi', 'Fries & snacks', 'Pasta', 'Pizza'] },
  { title: 'All-day bites', items: ['Burgers', 'Indian dishes', 'Breakfast', 'Desserts'] },
]

const gallery = [
  { src: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=85', alt: 'Latte on a café table', className: 'gallery-wide' },
  { src: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=85', alt: 'Fresh pizza on a table', className: 'gallery-tall' },
  { src: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=900&q=85', alt: 'Colourful café interior', className: 'gallery-square' },
  { src: 'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=900&q=85', alt: 'Artistic bowl of food', className: 'gallery-square' },
]

export default function Page() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [reserveOpen, setReserveOpen] = useState(false)
  const [expandedMenu, setExpandedMenu] = useState<number | null>(null)

  const closeMobile = () => setMobileOpen(false)

  return (
    <main className="site-shell">
      <div className="top-note"><span className="dot" /> Open daily · 8:00 AM — 11:30 PM <span className="top-note-location">Shivajinagar, Pune</span></div>
      <nav className="nav-wrap" aria-label="Primary navigation">
        <a href="#top" className="brand-mark" onClick={closeMobile}>
          <span>CAFE</span>
          <strong>FLYING<br />GYPSY&apos;S</strong>
        </a>
        <div className={`nav-links ${mobileOpen ? 'nav-links-open' : ''}`}>
          <a href="#menu" onClick={closeMobile}>Menu</a>
          <a href="#story" onClick={closeMobile}>Our story</a>
          <a href="#gallery" onClick={closeMobile}>Gallery</a>
          <a href="#visit" onClick={closeMobile}>Find us</a>
          <button className="nav-reserve" onClick={() => { setReserveOpen(true); closeMobile() }}>Reserve a table <ArrowUpRight aria-hidden="true" /></button>
        </div>
        <button className="menu-toggle" aria-label={mobileOpen ? 'Close menu' : 'Open menu'} aria-expanded={mobileOpen} onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X /> : <Menu />}</button>
      </nav>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow"><Sparkles aria-hidden="true" /> A little offbeat. A lot delicious.</p>
          <h1>Come for the<br /><em>coffee.</em> Stay for<br />the <span>stories.</span></h1>
          <p className="hero-lede">An artistic neighbourhood café in the heart of Shivajinagar, made for slow mornings, long conversations and everything in between.</p>
          <div className="hero-actions"><button className="button button-saffron" onClick={() => setReserveOpen(true)}>Reserve a table <ArrowUpRight aria-hidden="true" /></button><a className="text-link" href="#menu">Explore the menu <span>↓</span></a></div>
          <div className="hero-detail"><span>VEG · VEGAN OPTIONS</span><span className="detail-line" /><span>LAPTOP FRIENDLY</span></div>
        </div>
        <div className="hero-art" aria-label="A coffee and a slice of café life" role="img">
          <div className="hero-image-wrap"><img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1400&q=90" alt="Coffee being served at a warm café table" /></div>
          <div className="scribble scribble-one">good<br />vibes</div>
          <div className="hero-sticker">PUNE<br /><small>411004</small></div>
          <div className="hero-caption">A bright corner<br />in the city <span>✳</span></div>
        </div>
      </section>

      <section className="marquee" aria-label="Café offerings"><div>COFFEE <span>✳</span> CONVERSATIONS <span>✳</span> COMFORT FOOD <span>✳</span> CREATIVE ENERGY <span>✳</span> COFFEE <span>✳</span> CONVERSATIONS <span>✳</span></div></section>

      <section className="intro-section section-pad" id="story">
        <div className="section-kicker">01 / THE GYPSY SPIRIT</div>
        <div className="intro-grid"><div><h2>Not just a café.<br /><span>A place to be.</span></h2></div><div className="intro-copy"><p>CAFE FLYING GYPSY&apos;S is an artistic, vibrant café in Shivajinagar, Pune. Come in for a morning coffee, settle in with your laptop, or pull up a chair for a proper catch-up.</p><p>Our menu wanders from Indian comfort food to continental favourites and fusion-style bites — there&apos;s always something familiar, and something new to try.</p><a className="arrow-link" href="#visit">Find your way here <ArrowUpRight aria-hidden="true" /></a></div></div>
        <div className="feature-row"><div className="feature-card blue-card"><Coffee aria-hidden="true" /><strong>Slow coffee,<br />easy mornings.</strong><span>Hot brews & cold pours</span></div><div className="feature-card cream-card"><span className="feature-symbol">⌁</span><strong>Make yourself<br />at home.</strong><span>Outdoor seating & Wi-Fi</span></div><div className="feature-card coral-card"><span className="feature-symbol">✳</span><strong>Come hungry.<br />Leave happy.</strong><span>Indian, continental & more</span></div></div>
      </section>

      <section className="menu-section section-pad" id="menu"><div className="section-kicker light-kicker">02 / SOMETHING FOR EVERY MOOD</div><div className="menu-heading"><h2>The menu<br /><em>wanders.</em></h2><p>From your first cup to your last bite, find your kind of comfort.</p></div><div className="menu-list">{menuGroups.map((group, index) => <div className={`menu-row ${expandedMenu === index ? 'menu-row-open' : ''}`} key={group.title}><button onClick={() => setExpandedMenu(expandedMenu === index ? null : index)} aria-expanded={expandedMenu === index}><span className="menu-number">0{index + 1}</span><strong>{group.title}</strong><span className="menu-items-preview">{group.items.join(' · ')}</span>{expandedMenu === index ? <Minus aria-hidden="true" /> : <Plus aria-hidden="true" />}</button>{expandedMenu === index && <div className="menu-expanded">{group.items.map(item => <span key={item}>{item}</span>)}</div>}</div>)}</div><div className="menu-footnote">Vegetarian options available · Vegan options available</div></section>

      <section className="gallery-section section-pad" id="gallery"><div className="section-kicker">03 / LOOK AROUND</div><div className="gallery-header"><h2>A space with<br /><span>some soul.</span></h2><p>Colour on the walls. Music in the air. A little room to make the day your own.</p></div><div className="gallery-grid">{gallery.map(image => <div className={`gallery-image ${image.className}`} key={image.src}><img src={image.src} alt={image.alt} loading="lazy" /></div>)}</div></section>

      <section className="visit-section section-pad" id="visit"><div className="visit-card"><div><div className="section-kicker">04 / COME SAY HELLO</div><h2>Find us in<br /><em>Shivajinagar.</em></h2><p>1201-A/4, GH Patil Path<br />Shivajinagar, Pune<br />Maharashtra 411004, India</p><div className="visit-actions"><a className="button button-saffron" href="https://www.google.com/maps/search/?api=1&query=CAFE+FLYING+GYPSY%27S%2C+1201-A%2F4%2C+GH+Patil+Path%2C+Shivajinagar%2C+Pune" target="_blank" rel="noreferrer">Get directions <Compass aria-hidden="true" /></a><a className="button button-outline" href="tel:+919604147147"><Phone aria-hidden="true" /> Call now</a></div></div><div className="hours-card"><span>OPEN EVERY DAY</span><strong>8:00 AM<br />— 11:30 PM</strong><small>Good coffee doesn&apos;t take days off.</small></div></div></section>

      <section className="reserve-strip"><div><span className="section-kicker">05 / MAKE IT A PLAN</span><h2>Bring your people.</h2><p>For catch-ups, coffee dates, or a table with your laptop. Reserve a spot and we&apos;ll see you soon.</p></div><button className="button button-dark" onClick={() => setReserveOpen(true)}>Reserve a table <ArrowUpRight aria-hidden="true" /></button></section>

      <footer className="footer"><div className="footer-brand"><a href="#top" className="brand-mark brand-mark-light"><span>CAFE</span><strong>FLYING<br />GYPSY&apos;S</strong></a><p>A colourful corner<br />of Shivajinagar, Pune.</p></div><div className="footer-col"><span>Explore</span><a href="#menu">Menu</a><a href="#story">Our story</a><a href="#gallery">Gallery</a><a href="#visit">Find us</a></div><div className="footer-col"><span>Say hello</span><a href="tel:+919604147147">+91 96041 47147</a><a href="mailto:contact@cafeflyinggypsys.online">contact@cafeflyinggypsys.online</a><a href="https://www.instagram.com/cafeflyinggypsys" target="_blank" rel="noreferrer"><span aria-hidden="true">◎</span> @cafeflyinggypsys</a></div><div className="footer-social"><a href="https://www.instagram.com/cafeflyinggypsys" target="_blank" rel="noreferrer" aria-label="Instagram"><span className="social-glyph">◎</span></a><a href="mailto:contact@cafeflyinggypsys.online" aria-label="Email"><span className="footer-mail-icon">@</span></a></div><div className="footer-bottom"><span>© {new Date().getFullYear()} CAFE FLYING GYPSY&apos;S</span><span>Made for slow days & good company.</span></div></footer>

      <div className="floating-actions"><a href="tel:+919604147147" aria-label="Call CAFE FLYING GYPSY'S"><Phone aria-hidden="true" /></a><button onClick={() => setReserveOpen(true)} aria-label="Reserve a table"><CalendarDays aria-hidden="true" /></button></div>

      {reserveOpen && <div className="modal-backdrop" role="presentation" onClick={() => setReserveOpen(false)}><div className="reserve-modal" role="dialog" aria-modal="true" aria-labelledby="reserve-title" onClick={event => event.stopPropagation()}><button className="modal-close" onClick={() => setReserveOpen(false)} aria-label="Close reservation form"><X /></button><div className="section-kicker">RESERVE A TABLE</div><h2 id="reserve-title">Let&apos;s make<br /><em>space for you.</em></h2><p>Share a few details and the café team can confirm your table by phone.</p><form onSubmit={event => { event.preventDefault(); setReserveOpen(false); window.alert('Thanks — the café team will get in touch to confirm your table.') }}><label>Name<input required name="name" placeholder="Your name" /></label><label>Phone<input required name="phone" type="tel" placeholder="Your phone number" /></label><div className="form-row"><label>Date<input required name="date" type="date" /></label><label>Guests<select name="guests" defaultValue="2"><option>2 guests</option><option>3 guests</option><option>4 guests</option><option>5+ guests</option></select></label></div><button className="button button-saffron form-submit" type="submit">Send request <ArrowUpRight aria-hidden="true" /></button></form><small>No booking provider is connected yet. Your request is not confirmed until the café calls you.</small></div></div>}
    </main>
  )
}
